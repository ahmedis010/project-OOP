package com.mycompany.escaperoom;


/**
 * interface method that implements in Rooms class and return the story about
 * the room for every subclass
 */
public interface Story {

    public abstract String Story();
}

